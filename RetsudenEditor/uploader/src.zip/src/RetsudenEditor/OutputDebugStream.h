#pragma once

void OutputDebugStream( const char *format, ... );
